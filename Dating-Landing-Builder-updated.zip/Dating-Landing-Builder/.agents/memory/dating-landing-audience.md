---
name: Dating landing audience
description: The user's initial traffic plan and hosting preference for the dating affiliate landing.
---

The supplied launch plan prioritizes India as the first GEO, using PopAds popunder traffic and an SOI dating offer. The user plans to host the finished landing on their own server and domain.

**Why:** These are constraints from the user's supplied launch plan and hosting request, not facts recoverable from the code.

**How to apply:** Keep the default language and low-cost static-hosting guidance aligned with this initial test unless the user changes the plan.
